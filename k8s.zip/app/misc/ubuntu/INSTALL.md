# Installing Eclipse/Lombok in Ubuntu Linux

- Download "lombok.jar" from <https://projectlombok.org/download> into /home/rubens/bin/lombok.jar

```bash
sudo snap install --classic eclipse
cp eclipse.ini /home/rubens/eclipse/eclipse.ini
cp eclipse_eclipse.desktop  ~/.local/share/applications/eclipse_eclipse.desktop
```
